#pragma once

// CServerSocket ����Ŀ��

#include "FWQDlg.h"
class CFWQDlg;

class CServerSocket : public CSocket
{
public:
	CFWQDlg* m_pDlg;
	CServerSocket();
	virtual ~CServerSocket();
	virtual void OnAccept(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
};


